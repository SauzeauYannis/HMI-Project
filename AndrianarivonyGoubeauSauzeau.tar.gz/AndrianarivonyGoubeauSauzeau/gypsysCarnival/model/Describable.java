package gypsysCarnival.model;

public interface Describable {

	// Interface allowing display the description of place or game
	void readDescription();

}